		<header id="header">

			<!-- start Navbar (Header) -->
			<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function">

				<div class="container">
					
					<div class="logo-wrapper">
						<div class="logo">
							<a href="index.php"><img src="WinYa-Education-logo.png" style="max-width: 75%;" alt="Logo" /></a>
						</div>
					</div>
				
					<div class="nav-mini-wrapper pull-right">
						<ul class="nav-mini sign-in">
							<li>
								<a href="logout.php" >Logout</a>
							</li>
						</ul>
					</div>
				
				</div>
				
				<div id="slicknav-mobile"></div>
				
			</nav>
		</header>

		