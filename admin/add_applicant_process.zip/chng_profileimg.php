<?php 
	include('include/config.php');

?>