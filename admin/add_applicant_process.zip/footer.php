      <footer>
          <div class="pull-right">
            Winya Education
          </div>
          <div class="clearfix"></div>
        </footer>